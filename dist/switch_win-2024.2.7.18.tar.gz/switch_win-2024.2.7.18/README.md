# 功能
Ctrl+Shift+数字 可以确定的切换到窗口  
(省略了视觉判断的过程)

# 用法
添加开机启动以检测按键

# bug反馈
建议或bug请反馈至yanchengxin@yeah.net
